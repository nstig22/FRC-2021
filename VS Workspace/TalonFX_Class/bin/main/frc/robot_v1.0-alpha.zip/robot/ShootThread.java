/////////////////////////////////////////////////////////////////////
//  File:  ShootThread.java
/////////////////////////////////////////////////////////////////////
//
//Purpose:  Defines the thread class responsible for shooting the
//          ball.  Intended to be activated with a joystick button
//          or an autonomous call.
//
//Programmers:  
//
//Revisions:  Completely rewritten 02/01/2021
//
//Remarks: 
//
//         Implementing a drive thread for autonomous
//         operations.  Add the various movements within the run()
//         function.  Attempts have been made to simplify and make
//         functions consistent.
//

/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
package frc.robot;

/////////////////////////////////////////////////////////////////////
//  Class:  ShootThread
/////////////////////////////////////////////////////////////////////
//
//Purpose: Defines the parameters used to drive the robot.
//
//
//Remarks:  FRC iterative robot template.
//
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
class ShootThread implements Runnable {
	String name;
	Thread t;
	Runtime r = Runtime.getRuntime();
	private Delay delay;



	// Fixed parameters for shooter operation. Specified here to facilitate
	// changes without confusion in the various functions using these
	// variables.
	final double ROT_SPEED = 0.5; // Starting rotation speed for turning
	// As we approach the target we reduce the speed by this factor
	final double ROT_ATTEN = 1.5;
	// proximity (in degrees) to target angle stage 1 rotation attenuation rate
	final double ANGL_PROX_1 = 25.0;
	// proximity (in degrees) to target angle stage 2 rotation attenuation rate
	final double ANGL_PROX_2 = 5.0;

	public static double position1;
	public double initPosition1;

	public double init_Angle;

	// Constructor
	ShootThread(String threadname) {

	
        Robot.lf_shoot.setVelocity();
        
		
		name = threadname;
		t = new Thread(this, name);
		System.out.println("New thread: " + t);
		delay = new Delay();
		t.start(); // Start the thread
	}

	public void run() {
		while (Robot.shoot.t.isAlive() == true) {

            Robot.shoot_thread_active = true;

            Robot.lf_shoot.setVelocity();

			
            delay.delay_milliseconds(2000);
            
            Robot.lf_shoot.stop();

		
			// Wait for the thread to complete
			try {
				Robot.shoot.t.join();
			} catch (InterruptedException e) {
				System.out.println(name + "Interrupted.");
			}

			System.out.println(name + "Exiting Shoot Thread");
			r.gc(); // force garbage collection (freeing of memory resources)

			// Reset flag
			Robot.shoot_thread_active = false;
		}

		// Should get a false indication
		System.out.println("Thread Status = " + Robot.shoot.t.isAlive());
	}

}